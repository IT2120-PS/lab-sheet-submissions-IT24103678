setwd("C:\\Users\\M S I\\Desktop\\New folder")

observed <- c(120, 95, 85, 100)

prob <- c(0.25, 0.25, 0.25, 0.25)

result <- chisq.test(x = observed, p = prob)

print(result)

result$expected